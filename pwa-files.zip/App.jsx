import { useState, useCallback, useMemo, useEffect, useRef } from "react";
import { auth, db } from "./firebase";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, deleteUser, EmailAuthProvider, reauthenticateWithCredential } from "firebase/auth";
import { doc, setDoc, getDoc, deleteDoc } from "firebase/firestore";
import ALL_CARDS from "./cards";

const UI={en:{practice:"Practice",progress:"Progress",settings:"Settings",flipHint:"tap to flip · swipe ← →",hint:"Hint",gotIt:"Got it! →",still:"← Still learning",mastered:"Mastered",learning:"Learning",due:"Due",total:"Total",flips:"reviewed",done:"Target hit! ✨",example:"Example",play:"▶ Play",theme:"Appearance",autoPlay:"Auto-play sound",target:"Daily target",perDay:"/day",logout:"Log out",deleteAcc:"Delete account",deleteWarn:"Permanently deletes everything.",confirm:"Confirm delete",cancel:"Cancel",pw:"Password",mastery:"Overall mastery",week:"This week",levels:"Levels",cats:"Categories",pracDue:"Due cards",pracLearn:"Learning cards",pracAll:"Practice all",exit:"Exit",allDone:"All caught up!",back:"Back to categories",lang:"Interface language",shuffle:"Shuffle",replay:"Replay tutorial",new:"New",reviewing:"Reviewing",improving:"Improving",strong:"Strong",master:"Mastered",browseAll:"Browse all",dueNow:"due now",search:"Search cards...",fav:"Favourites",noResults:"No cards found",installApp:"Install app",installDesc:"Add to your home screen for quick access",installed:"Already installed",iosInstTitle:"Install on iPhone / iPad",iosInst1:"Tap the Share button",iosInst2:"Scroll down and tap",iosInst3:"\"Add to Home Screen\"",iosInstDone:"Done! Open from home screen.",installSuccess:"Opening install prompt…"},de:{practice:"Übung",progress:"Fortschritt",settings:"Einstellungen",flipHint:"Tippen = umdrehen · Wischen ← →",hint:"Hinweis",gotIt:"Kann ich! →",still:"← Noch lernen",mastered:"Gemeistert",learning:"Am Lernen",due:"Fällig",total:"Gesamt",flips:"geübt",done:"Geschafft! ✨",example:"Beispiel",play:"▶",theme:"Aussehen",autoPlay:"Auto-Ton",target:"Tagesziel",perDay:"/Tag",logout:"Abmelden",deleteAcc:"Konto löschen",deleteWarn:"Löscht alles unwiderruflich.",confirm:"Endgültig löschen",cancel:"Abbrechen",pw:"Passwort",mastery:"Gesamtfortschritt",week:"Diese Woche",levels:"Stufen",cats:"Kategorien",pracDue:"Fällige Karten",pracLearn:"Lernkarten",pracAll:"Alle üben",exit:"Beenden",allDone:"Alles erledigt!",back:"Zurück",lang:"Sprache",shuffle:"Mischen",replay:"Tutorial wiederholen",new:"Neu",reviewing:"Wiederholung",improving:"Fortschritt",strong:"Sicher",master:"Gemeistert",browseAll:"Alle ansehen",dueNow:"fällig",search:"Karten suchen...",fav:"Favoriten",noResults:"Keine Karten gefunden",installApp:"App installieren",installDesc:"Zum Startbildschirm hinzufügen",installed:"Bereits installiert",iosInstTitle:"Auf iPhone / iPad installieren",iosInst1:"Tippe auf das Teilen-Symbol",iosInst2:"Scrolle nach unten und tippe",iosInst3:"\"Zum Home-Bildschirm\"",iosInstDone:"Fertig! Öffne von deinem Startbildschirm.",installSuccess:"Installationsaufforderung wird geöffnet…"}};

// ——— PWA INSTALL HOOK ———
// Handles beforeinstallprompt, platform detection, standalone detection
function usePWAInstall(){
  const[deferredPrompt,setDeferredPrompt]=useState(null);
  const[isInstalled,setIsInstalled]=useState(false);
  const[platform,setPlatform]=useState("unknown"); // "ios","android","desktop","unknown"

  useEffect(()=>{
    // Detect platform
    const ua=navigator.userAgent||"";
    const isIOS=/iPad|iPhone|iPod/.test(ua)||(navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1);
    const isAndroid=/Android/.test(ua);
    setPlatform(isIOS?"ios":isAndroid?"android":"desktop");

    // Detect if already in standalone mode (installed)
    const isStandalone=window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone===true;
    setIsInstalled(isStandalone);

    // Listen for display-mode changes
    const mq=window.matchMedia("(display-mode: standalone)");
    const onChange=(e)=>setIsInstalled(e.matches);
    mq.addEventListener?.("change",onChange);

    // Capture beforeinstallprompt (Chrome/Edge/Android)
    const onPrompt=(e)=>{e.preventDefault();setDeferredPrompt(e);};
    window.addEventListener("beforeinstallprompt",onPrompt);

    // Detect successful install
    const onInstalled=()=>{setIsInstalled(true);setDeferredPrompt(null);};
    window.addEventListener("appinstalled",onInstalled);

    return()=>{
      window.removeEventListener("beforeinstallprompt",onPrompt);
      window.removeEventListener("appinstalled",onInstalled);
      mq.removeEventListener?.("change",onChange);
    };
  },[]);

  const triggerInstall=useCallback(async()=>{
    if(!deferredPrompt)return false;
    deferredPrompt.prompt();
    const result=await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    return result.outcome==="accepted";
  },[deferredPrompt]);

  return{
    canInstall:!!deferredPrompt,        // Android/Chrome/Edge: prompt available
    isInstalled,                          // Already running as PWA
    isIOS:platform==="ios",              // Show iOS instructions instead
    isAndroid:platform==="android",
    isDesktop:platform==="desktop",
    triggerInstall,                        // Call to show Chrome install prompt
    platform,
  };
}
const CAT_DE={Numbers:"Zahlen","Family & People":"Familie","Body Parts":"Körperteile","Nature & Weather":"Natur & Wetter",Colors:"Farben","Food & Home":"Essen & Haus",Places:"Orte",Time:"Zeit",Emotions:"Gefühle",Adjectives:"Adjektive",Verbs:"Verben","Common Words":"Häufige Wörter",Sentences:"Sätze"};
const CAT_EMOJI={Numbers:"🔢","Family & People":"👨‍👩‍👧","Body Parts":"🫳","Nature & Weather":"🌧️",Colors:"🎨","Food & Home":"🏠",Places:"📍",Time:"⏰",Emotions:"💛",Adjectives:"✨",Verbs:"🏃","Common Words":"💬",Sentences:"🗣️"};

const CATEGORIES=["All",...Array.from(new Set(ALL_CARDS.map(c=>c.cat)))];
const CC={Numbers:"#8B7355","Family & People":"#A0522D","Body Parts":"#CD853F","Nature & Weather":"#2E8B57",Colors:"#DAA520","Food & Home":"#6B8E23",Places:"#4682B4",Time:"#B8860B",Emotions:"#C97B84",Adjectives:"#5F9EA0",Verbs:"#7B68AE","Common Words":"#708090",Sentences:"#BC8F8F"};
const LVL_C=["#D06060","#D89050","#C8A040","#80B050","#40A050"];
// ——— SPACED REPETITION: Interval per level in ms ———
// Level 1 = 0 (review immediately), Level 2 = 48h, Level 3 = 96h, Level 4 = 7d, Level 5 = 30d
const LVL_INTERVALS=[0,48*36e5,96*36e5,7*864e5,30*864e5];
const LVL_LABELS_SHORT=["now","48h","96h","7d","30d"];
function cleanForSpeech(t){return t.replace(/\s*\(.*?\)\s*/g," ").replace(/\n/g," ").trim();}

// Get card data: {level, lastReviewedAt, nextReviewAt}
function getLevel(cl,id){
  const d=cl[id];
  if(!d)return{level:1,lastReviewedAt:null,nextReviewAt:null};
  // Migration: old format had lastCorrect instead of lastReviewedAt
  if(d.lastCorrect&&!d.lastReviewedAt)return{level:d.level||1,lastReviewedAt:d.lastCorrect,nextReviewAt:d.nextReviewAt||null};
  return{level:d.level||1,lastReviewedAt:d.lastReviewedAt||null,nextReviewAt:d.nextReviewAt||null};
}

// Check if card is due: nextReviewAt <= now (or never reviewed / level 1)
function isDue(cl,id,timeOffset=0){
  const c=getLevel(cl,id);
  if(c.level<=1||!c.nextReviewAt)return true;
  return(Date.now()+timeOffset)>=new Date(c.nextReviewAt).getTime();
}

// Correct answer: level+1, schedule next review
function lvlUp(cl,id,timeOffset=0){
  const c=getLevel(cl,id);
  const newLevel=Math.min(c.level+1,5);
  const now=new Date(Date.now()+timeOffset);
  const interval=LVL_INTERVALS[newLevel-1];
  const nextReview=new Date(now.getTime()+interval);
  console.log(`%c✅ CORRECT: Card ${id} — Lv${c.level}→Lv${newLevel} | Next review: ${interval===0?"now":LVL_LABELS_SHORT[newLevel-1]} (${nextReview.toLocaleString()})`,"color:#40A050;font-weight:bold");
  return{...cl,[id]:{level:newLevel,lastReviewedAt:now.toISOString(),nextReviewAt:nextReview.toISOString()}};
}

// Incorrect answer: level-1, schedule next review
function lvlDown(cl,id,timeOffset=0){
  const c=getLevel(cl,id);
  const newLevel=Math.max(c.level-1,1);
  const now=new Date(Date.now()+timeOffset);
  const interval=LVL_INTERVALS[newLevel-1];
  const nextReview=new Date(now.getTime()+interval);
  console.log(`%c❌ INCORRECT: Card ${id} — Lv${c.level}→Lv${newLevel} | Next review: ${interval===0?"now":LVL_LABELS_SHORT[newLevel-1]} (${nextReview.toLocaleString()})`,"color:#D06060;font-weight:bold");
  return{...cl,[id]:{level:newLevel,lastReviewedAt:now.toISOString(),nextReviewAt:nextReview.toISOString()}};
}

// Format relative time for display
function fmtRelTime(iso,timeOffset=0){
  if(!iso)return"—";
  const d=new Date(iso).getTime();
  const now=Date.now()+timeOffset;
  const diff=d-now;
  if(diff<=0)return"Now";
  const h=Math.floor(diff/36e5);
  if(h<1)return`${Math.ceil(diff/60000)}m`;
  if(h<48)return`${h}h`;
  const days=Math.floor(h/24);
  return`${days}d`;
}

function shuffleArr(a){const r=[...a];for(let i=r.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[r[i],r[j]]=[r[j],r[i]];}return r;}

const TL={bgGrad:"linear-gradient(155deg,#F6F9FC 0%,#F0F3F8 30%,#EAF0F6 55%,#E6F0F4 75%,#F2F6FA 100%)",cardFront:"linear-gradient(155deg,#FFF,#FBFDFF 40%,#F6F9FE 70%,#F4F8FC)",text:"#1E1A20",sub:"#58505E",muted:"#908898",faint:"#C8C0D0",hintBg:"rgba(160,112,192,.06)",hintBd:"rgba(160,112,192,.15)",hintTx:"#5E4878",trickBg:"rgba(88,176,112,.06)",trickBd:"rgba(88,176,112,.16)",trickTx:"#38784A",pillBg:"#FFF",pillBd:"rgba(0,0,0,.06)",btnBg:"#FFF",btnBd:"rgba(0,0,0,.08)",btnTx:"#78708A",dotBg:"rgba(0,0,0,.07)",divider:"rgba(0,0,0,.06)",cardShadow:"0 8px 32px rgba(30,20,40,.06),0 2px 8px rgba(0,0,0,.03)",accent:"#4A8EC2",pronBg:"rgba(74,142,194,.06)",pronBd:"rgba(74,142,194,.16)",speedBg:"rgba(74,142,194,.04)",speedBd:"rgba(74,142,194,.10)",speedActive:"rgba(74,142,194,.12)",inputBg:"#FFF",inputBd:"rgba(0,0,0,.10)",overlayBg:"rgba(244,248,252,.98)",tabBg:"#FFF",tabBd:"rgba(0,0,0,.06)",barFill:"#4A8EC2",exBg:"rgba(80,168,184,.05)",exBd:"rgba(80,168,184,.14)",exTx:"#28708A",catCardBg:"#FFF",catCardBd:"rgba(0,0,0,.05)",catCardShadow:"0 2px 12px rgba(0,0,0,.04)"};
const TD={bgGrad:"linear-gradient(155deg,#10141A 0%,#121824 30%,#101418 55%,#121620 75%,#141820 100%)",cardFront:"linear-gradient(155deg,#182028,#161A24 40%,#141820)",text:"#EDE8F0",sub:"#8A8098",muted:"#585060",faint:"#383040",hintBg:"rgba(255,255,255,.04)",hintBd:"rgba(255,255,255,.08)",hintTx:"#8A8098",trickBg:"rgba(88,176,112,.08)",trickBd:"rgba(88,176,112,.14)",trickTx:"#78C098",pillBg:"rgba(255,255,255,.04)",pillBd:"rgba(255,255,255,.06)",btnBg:"rgba(255,255,255,.05)",btnBd:"rgba(255,255,255,.08)",btnTx:"#8A8098",dotBg:"rgba(255,255,255,.08)",divider:"rgba(255,255,255,.05)",cardShadow:"0 8px 32px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.03)",accent:"#6AAED8",pronBg:"rgba(106,174,216,.10)",pronBd:"rgba(106,174,216,.20)",speedBg:"rgba(255,255,255,.03)",speedBd:"rgba(255,255,255,.06)",speedActive:"rgba(106,174,216,.14)",inputBg:"rgba(255,255,255,.06)",inputBd:"rgba(255,255,255,.10)",overlayBg:"rgba(16,20,26,.98)",tabBg:"#161A24",tabBd:"rgba(255,255,255,.06)",barFill:"#6AAED8",exBg:"rgba(80,168,184,.08)",exBd:"rgba(80,168,184,.12)",exTx:"#78C0D0",catCardBg:"rgba(255,255,255,.04)",catCardBd:"rgba(255,255,255,.06)",catCardShadow:"0 2px 12px rgba(0,0,0,.2)"};
const SPEEDS=[{key:"normal",label:"Normal",rate:.75,emoji:"🗣️"},{key:"slow",label:"Slow",rate:.50,emoji:"🐢"}];

// ——— LANDING PAGE ———
const PREVIEW_CARDS=[
  {front:"Hello",back:"नमस्ते",tl:"Namaste",color:"#4A8EC2"},
  {front:"Water",back:"पानी",tl:"Paani",color:"#50A8B8"},
  {front:"Thank you",back:"शुक्रिया",tl:"Shukriya",color:"#5B8ED0"},
  {front:"Beautiful",back:"सुन्दर",tl:"Sundar",color:"#6B7EC8"},
  {front:"Family",back:"परिवार",tl:"Parivaar",color:"#D89050"},
];
const FEATURES=[
  {icon:"🗣️",title:"Audio pronunciation",desc:"Normal & slow speed for every word, plus example sentences"},
  {icon:"🧠",title:"Spaced repetition",desc:"5-level system adapts to what you know and what needs work"},
  {icon:"🇩🇪",title:"Built for German speakers",desc:"Memory tricks, hints & full German interface available"},
  {icon:"🎯",title:"Set daily goals",desc:"Choose your daily flip target and build a consistent learning habit"},
  {icon:"📝",title:"Rich card details",desc:"Flip to see gender, singular/plural, transliteration & example sentences"},
  {icon:"📊",title:"Track your progress",desc:"Mastery charts, level breakdowns & category progress at a glance"},
];

function LandingPage({onStart,onLogin}){
  const[cardIdx,setCardIdx]=useState(0);
  const[phase,setPhase]=useState("show"); // "show","flip","slide"
  const[fadeIn,setFadeIn]=useState(false);
  useEffect(()=>{setTimeout(()=>setFadeIn(true),100);},[]);
  useEffect(()=>{
    const cycle=()=>{
      setPhase("flip");
      setTimeout(()=>{setPhase("slide");
        setTimeout(()=>{setCardIdx(i=>(i+1)%PREVIEW_CARDS.length);setPhase("show");},600);
      },1800);
    };
    const iv=setInterval(cycle,3600);
    return()=>clearInterval(iv);
  },[]);
  const pc=PREVIEW_CARDS[cardIdx];
  const nextPc=PREVIEW_CARDS[(cardIdx+1)%PREVIEW_CARDS.length];
  return(
    <div style={{minHeight:"100vh",background:"linear-gradient(170deg,#F6F9FC 0%,#EDF2F8 25%,#E8EEF6 50%,#E4F0F4 75%,#F2F6FA 100%)",fontFamily:"'Outfit',sans-serif",overflow:"hidden"}}>
      <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap" rel="stylesheet"/>
      <style>{`
        @keyframes floatA{0%,100%{transform:translateY(0) rotate(-6deg)}50%{transform:translateY(-12px) rotate(-6deg)}}
        @keyframes floatB{0%,100%{transform:translateY(0) rotate(4deg)}50%{transform:translateY(-10px) rotate(4deg)}}
        @keyframes floatC{0%,100%{transform:translateY(0) rotate(-2deg)}50%{transform:translateY(-8px) rotate(-2deg)}}
        .land-fade{opacity:0;transform:translateY(24px);transition:opacity .8s ease,transform .8s ease}
        .land-fade.in{opacity:1;transform:translateY(0)}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0}
      `}</style>
      <nav style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"20px 24px",maxWidth:960,margin:"0 auto"}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:22,fontFamily:"'Noto Sans Devanagari',sans-serif",fontWeight:700,color:"#4A8EC2"}}>हिं</span>
          <span style={{fontSize:17,fontWeight:800,color:"#1E1A20",letterSpacing:-.5}}>Hindi Flashcards</span>
        </div>
        <button onClick={onLogin} style={{padding:"9px 20px",borderRadius:12,border:"1.5px solid rgba(74,142,194,.2)",background:"#FFF",color:"#4A8EC2",fontSize:14,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>Log in</button>
      </nav>
      <div className={`land-fade ${fadeIn?"in":""}`} style={{maxWidth:960,margin:"0 auto",padding:"40px 24px 0",display:"flex",flexDirection:"column",alignItems:"center"}}>
        <h1 style={{fontSize:"clamp(32px,6vw,56px)",fontWeight:900,textAlign:"center",lineHeight:1.1,color:"#1E1A20",maxWidth:640,letterSpacing:"-1.5px"}}>
          Build Hindi vocabulary<br/>efficiently with<br/><span style={{color:"#4A8EC2"}}>smart flashcards</span>
        </h1>
        <p style={{fontSize:"clamp(16px,2.5vw,19px)",color:"#58505E",textAlign:"center",maxWidth:500,lineHeight:1.6,marginTop:16,fontWeight:400}}>
          {ALL_CARDS.length} cards across 13 categories. Audio pronunciation, spaced repetition, and memory tricks designed for German speakers.
        </p>
        <div style={{display:"flex",gap:12,marginTop:28,flexWrap:"wrap",justifyContent:"center"}}>
          <button onClick={onStart} style={{padding:"15px 36px",borderRadius:16,border:"none",background:"linear-gradient(135deg,#4A8EC2,#5BA0D4)",color:"#FFF",fontSize:17,fontFamily:"inherit",fontWeight:700,cursor:"pointer",boxShadow:"0 4px 20px rgba(74,142,194,.3),0 1px 3px rgba(0,0,0,.08)",letterSpacing:-.3}}>Start learning →</button>
        </div>
      </div>
      {/* ——— Card stack animation ——— */}
      <div className={`land-fade ${fadeIn?"in":""}`} style={{transitionDelay:".2s",display:"flex",justifyContent:"center",padding:"48px 24px 20px",position:"relative"}}>
        <div style={{position:"relative",width:320,height:240}}>
          <div style={{position:"absolute",top:18,left:-20,width:160,height:100,borderRadius:16,background:"linear-gradient(135deg,#4A8EC2,#4A8EC2CC)",opacity:.12,animation:"floatA 4s ease-in-out infinite"}}/>
          <div style={{position:"absolute",bottom:10,right:-15,width:140,height:90,borderRadius:16,background:"linear-gradient(135deg,#5BA0D4,#5BA0D4CC)",opacity:.10,animation:"floatB 5s ease-in-out infinite"}}/>
          <div style={{position:"absolute",top:-5,right:30,width:120,height:80,borderRadius:14,background:"linear-gradient(135deg,#50A8B8,#50A8B8CC)",opacity:.08,animation:"floatC 4.5s ease-in-out infinite"}}/>
          <div style={{position:"absolute",left:"50%",top:"50%",transform:"translate(-50%,-50%)",width:270,height:180}}>
            {/* Next card peeking behind */}
            <div style={{position:"absolute",inset:0,borderRadius:20,background:"#FFF",border:"2px solid rgba(74,142,194,.08)",boxShadow:"0 8px 30px rgba(30,40,60,.06)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:20,transform:"scale(.94) translateY(8px)",opacity:.5}}>
              <div style={{fontSize:11,color:"#908898",letterSpacing:2,textTransform:"uppercase",fontWeight:600,marginBottom:8}}>English</div>
              <div style={{fontSize:28,fontWeight:800,color:"#1E1A20"}}>{nextPc.front}</div>
            </div>
            {/* Current card */}
            <div style={{position:"absolute",inset:0,perspective:800,transition:phase==="slide"?"transform .5s cubic-bezier(.4,0,.2,1),opacity .5s ease":"none",transform:phase==="slide"?"translateX(-120%) rotate(-8deg) scale(.9)":"translateX(0)",opacity:phase==="slide"?0:1,zIndex:2}}>
              <div style={{width:"100%",height:"100%",position:"relative",transformStyle:"preserve-3d",transition:"transform .6s cubic-bezier(.23,1,.32,1)",transform:phase==="flip"?"rotateY(180deg)":"rotateY(0)"}}>
                <div style={{position:"absolute",inset:0,backfaceVisibility:"hidden",WebkitBackfaceVisibility:"hidden",borderRadius:20,background:"#FFF",border:`2px solid ${pc.color}14`,boxShadow:"0 12px 40px rgba(30,40,60,.08),0 2px 8px rgba(0,0,0,.04)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:20}}>
                  <div style={{fontSize:11,color:"#908898",letterSpacing:2,textTransform:"uppercase",fontWeight:600,marginBottom:8}}>English</div>
                  <div style={{fontSize:32,fontWeight:800,color:"#1E1A20"}}>{pc.front}</div>
                  <div style={{marginTop:12,fontSize:12,color:"#C0C8D4"}}>tap to flip</div>
                </div>
                <div style={{position:"absolute",inset:0,backfaceVisibility:"hidden",WebkitBackfaceVisibility:"hidden",transform:"rotateY(180deg)",borderRadius:20,background:`linear-gradient(155deg,${pc.color}0A,#FFF 30%)`,border:`2px solid ${pc.color}18`,boxShadow:"0 12px 40px rgba(30,40,60,.08),0 2px 8px rgba(0,0,0,.04)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:20}}>
                  <div style={{fontSize:11,color:pc.color,letterSpacing:2,textTransform:"uppercase",fontWeight:700,marginBottom:6,fontFamily:"'Noto Sans Devanagari',sans-serif"}}>हिंदी</div>
                  <div style={{fontSize:36,fontWeight:700,color:"#1E1A20",fontFamily:"'Noto Sans Devanagari',sans-serif"}}>{pc.back}</div>
                  <div style={{fontSize:15,color:pc.color,fontWeight:600,marginTop:4}}>{pc.tl}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ——— Trust signals (under animation) ——— */}
      <div className={`land-fade ${fadeIn?"in":""}`} style={{transitionDelay:".3s",display:"flex",justifyContent:"center",gap:20,flexWrap:"wrap",padding:"0 24px 10px"}}>
        {["✓ 100% free","✓ No ads","✓ Works offline"].map(t=>(
          <span key={t} style={{fontSize:15,fontWeight:600,color:"#4A8EC2",letterSpacing:.2}}>{t}</span>
        ))}
      </div>
      {/* ——— Features grid ——— */}
      <div className={`land-fade ${fadeIn?"in":""}`} style={{transitionDelay:".4s",maxWidth:840,margin:"0 auto",padding:"30px 24px 40px"}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:14}}>
          {FEATURES.map((f,i)=>(
            <div key={i} style={{padding:"20px 18px",borderRadius:18,background:"#FFF",border:"1px solid rgba(74,142,194,.08)",boxShadow:"0 2px 12px rgba(30,40,60,.03)"}}>
              <div style={{fontSize:28,marginBottom:8}}>{f.icon}</div>
              <div style={{fontSize:15,fontWeight:700,color:"#1E1A20",marginBottom:4}}>{f.title}</div>
              <div style={{fontSize:13,color:"#58505E",lineHeight:1.5}}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>
      {/* ——— Bottom CTA ——— */}
      <div className={`land-fade ${fadeIn?"in":""}`} style={{transitionDelay:".5s",textAlign:"center",padding:"20px 24px 50px"}}>
        <button onClick={onStart} style={{padding:"15px 40px",borderRadius:16,border:"none",background:"linear-gradient(135deg,#4A8EC2,#5BA0D4)",color:"#FFF",fontSize:17,fontFamily:"inherit",fontWeight:700,cursor:"pointer",boxShadow:"0 4px 20px rgba(74,142,194,.3)"}}>Start learning Hindi →</button>
      </div>
    </div>
  );
}

function useSpeech(){const[s,ss]=useState(false);const[a,sa]=useState(null);const[v,sv]=useState(null);const r=useRef(null);const keepAlive=useRef(null);
  useEffect(()=>{if(typeof window==="undefined"||!window.speechSynthesis)return;r.current=window.speechSynthesis;const p=()=>{const vs=r.current.getVoices();sv(vs.find(x=>x.lang==="hi-IN"&&x.name.includes("Google"))||vs.find(x=>x.lang==="hi-IN"&&!x.localService)||vs.find(x=>x.lang==="hi-IN")||vs.find(x=>x.lang.startsWith("hi"))||null);};p();r.current.addEventListener("voiceschanged",p);return()=>r.current?.removeEventListener("voiceschanged",p);},[]);
  // Chrome bug fix: pause+resume every 5s to prevent audio degradation on long utterances
  const startKeepAlive=useCallback(()=>{if(keepAlive.current)clearInterval(keepAlive.current);keepAlive.current=setInterval(()=>{if(r.current&&r.current.speaking){r.current.pause();r.current.resume();}},5000);},[]);
  const stopKeepAlive=useCallback(()=>{if(keepAlive.current){clearInterval(keepAlive.current);keepAlive.current=null;}},[]);
  // speakParts: split on "/" and speak each part with a pause
  const speak=useCallback((t,rate=.75,k="normal")=>{if(!r.current)return;r.current.cancel();stopKeepAlive();
    const cleaned=cleanForSpeech(t);
    const parts=cleaned.split(/\s*\/\s*/).filter(Boolean);
    const speakPart=(i)=>{
      if(i>=parts.length){ss(false);sa(null);stopKeepAlive();return;}
      const u=new SpeechSynthesisUtterance(parts[i].trim());
      u.lang="hi-IN";u.rate=rate;u.pitch=1.05;if(v)u.voice=v;
      u.onstart=()=>{ss(true);sa(k);startKeepAlive();};
      u.onend=()=>{if(i<parts.length-1){setTimeout(()=>speakPart(i+1),450);}else{ss(false);sa(null);stopKeepAlive();}};
      u.onerror=()=>{ss(false);sa(null);stopKeepAlive();};
      r.current.speak(u);
    };
    speakPart(0);
  },[v,startKeepAlive,stopKeepAlive]);const stop=useCallback(()=>{r.current?.cancel();ss(false);sa(null);stopKeepAlive();},[stopKeepAlive]);return{speak,stop,speaking:s,activeSpeed:a,supported:typeof window!=="undefined"&&!!window.speechSynthesis};}
function useSwipe(onL,onR){const sx=useRef(0);const sy=useRef(0);return{onTouchStart:useCallback(e=>{sx.current=e.touches[0].clientX;sy.current=e.touches[0].clientY;},[]),onTouchEnd:useCallback(e=>{const dx=e.changedTouches[0].clientX-sx.current;const dy=e.changedTouches[0].clientY-sy.current;if(Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.5){dx>0?onR():onL();}},[onL,onR])};}

async function saveData(uid,d){try{await setDoc(doc(db,"users",uid),{...d,updatedAt:new Date().toISOString()},{merge:true});}catch(e){console.error(e);}}
async function loadData(uid){try{const s=await getDoc(doc(db,"users",uid));if(s.exists())return s.data();}catch(e){console.error(e);}return null;}

function PasswordInput({value,onChange,placeholder,onKeyDown,T}){const[v,setV]=useState(false);return(<div style={{position:"relative",width:"100%"}}><input type={v?"text":"password"} placeholder={placeholder} value={value} onChange={onChange} onKeyDown={onKeyDown} style={{width:"100%",padding:"14px 48px 14px 16px",borderRadius:14,border:`1.5px solid ${T.inputBd}`,background:T.inputBg,color:T.text,fontSize:16,fontFamily:"'Outfit',sans-serif",outline:"none",boxSizing:"border-box"}}/><button type="button" onClick={()=>setV(x=>!x)} tabIndex={-1} style={{position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",padding:"6px",color:T.muted,fontSize:16}}>{v?"🙈":"👁️"}</button></div>);}

const TUTORIAL=[{e:"👋",t:"Welcome!",b:"Learn Hindi with flashcards, audio & spaced repetition."},{e:"📚",t:"Flip & Swipe",b:"Tap to flip. Swipe right = got it, left = still learning."},{e:"💡",t:"Hints",b:"Tap '💡 Hint' for a clue — first letter, letter count, sound-alikes."},{e:"🏆",t:"5 Levels",b:"Correct → level up, wrong → level down. Higher levels repeat less."},{e:"🗣️",t:"Audio",b:"Normal & Slow speed. Example sentences with audio too."},{e:"🌐",t:"Deutsch?",b:"Switch to German in Settings. Every card has 🇩🇪 memory tricks."},{e:"📲",t:"Install the app!",b:"You can install Hindi Flashcards on your phone or computer! Go to Settings → 'Install App' for a native app experience."},{e:"🚀",t:"Ready!",b:"Pick a category and start — बहुत मज़ा आएगा!"}];
function TutorialModal({T,onDone}){const[s,setS]=useState(0);const t=TUTORIAL[s];const last=s===TUTORIAL.length-1;return(<div style={{position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.5)",padding:20,boxSizing:"border-box"}}><div style={{background:T.overlayBg,borderRadius:28,padding:"32px 24px 24px",width:"100%",maxWidth:380,textAlign:"center",boxShadow:"0 20px 60px rgba(0,0,0,.2)",backdropFilter:"blur(20px)"}}><div style={{fontSize:48,marginBottom:8}}>{t.e}</div><h2 style={{fontSize:22,fontWeight:800,color:T.text,margin:"0 0 8px"}}>{t.t}</h2><p style={{fontSize:15,color:T.sub,lineHeight:1.6,margin:"0 0 20px"}}>{t.b}</p><div style={{display:"flex",gap:4,justifyContent:"center",marginBottom:16}}>{TUTORIAL.map((_,i)=>(<div key={i} style={{width:i===s?18:8,height:5,borderRadius:3,background:i===s?T.accent:`${T.accent}30`,transition:"all .3s"}}/>))}</div><div style={{display:"flex",gap:10}}>{s>0&&<button onClick={()=>setS(s=>s-1)} style={{flex:1,padding:"12px",borderRadius:14,border:`1.5px solid ${T.pillBd}`,background:T.btnBg,color:T.sub,fontSize:15,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>←</button>}<button onClick={()=>last?onDone():setS(s=>s+1)} style={{flex:1,padding:"12px",borderRadius:14,border:"none",background:`linear-gradient(135deg,${T.accent},${T.accent}DD)`,color:"#FFF",fontSize:15,fontFamily:"inherit",fontWeight:700,cursor:"pointer"}}>{last?"Let's go!":"Next →"}</button></div><button onClick={onDone} style={{marginTop:8,background:"none",border:"none",color:T.muted,fontSize:13,fontFamily:"inherit",cursor:"pointer"}}>Skip</button></div></div>);}

function AuthScreen({T,onBack,initialMode}){const[isS,setIsS]=useState(initialMode==="signup");const[nm,setNm]=useState("");const[em,setEm]=useState("");const[pw,setPw]=useState("");const[err,setErr]=useState("");const[ld,setLd]=useState(false);const sub=async()=>{setErr("");if(isS&&!nm.trim()){setErr("Enter your name");return;}if(!em||!pw){setErr("Fill all fields");return;}if(pw.length<6){setErr("Min 6 chars");return;}setLd(true);try{if(isS){const c=await createUserWithEmailAndPassword(auth,em,pw);await setDoc(doc(db,"users",c.user.uid),{name:nm.trim(),cardLevels:{},stats:{totalMinutes:0,dailyLog:{},dailyTarget:25},lang:"en",showTutorial:true});}else await signInWithEmailAndPassword(auth,em,pw);}catch(e){setErr(e.code==="auth/invalid-credential"?"Invalid email/password.":e.code==="auth/email-already-in-use"?"Already registered.":e.message);}setLd(false);};const iS={width:"100%",padding:"14px 16px",borderRadius:14,border:`1.5px solid ${T.inputBd}`,background:T.inputBg,color:T.text,fontSize:16,fontFamily:"'Outfit',sans-serif",outline:"none",boxSizing:"border-box"};
return(<div style={{minHeight:"100vh",background:T.bgGrad,fontFamily:"'Outfit',sans-serif",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"24px 20px",boxSizing:"border-box"}}><link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap" rel="stylesheet"/><div style={{width:"100%",maxWidth:400}}>{onBack&&<button onClick={onBack} style={{display:"flex",alignItems:"center",gap:4,padding:"8px 14px",borderRadius:12,border:`1px solid ${T.pillBd}`,background:T.btnBg,color:T.sub,fontSize:13,fontFamily:"inherit",fontWeight:600,cursor:"pointer",marginBottom:28}}>← Back</button>}<div style={{textAlign:"center"}}><div style={{fontSize:15,letterSpacing:3,color:T.accent,fontWeight:700,marginBottom:6,fontFamily:"'Noto Sans Devanagari',sans-serif"}}>हिंदी सीखें</div><h1 style={{fontSize:30,fontWeight:800,margin:0,color:T.text}}>{isS?"Create your account":"Welcome back"}</h1>{isS&&<p style={{fontSize:14,color:T.muted,margin:"10px 0 0",lineHeight:1.5}}>Save your progress across devices and track your learning journey.</p>}<p style={{fontSize:15,color:T.sub,margin:"8px 0 24px"}}>{isS?"":"Log in to continue learning"}</p></div><div style={{display:"flex",flexDirection:"column",gap:12}}>{isS&&<input placeholder="Your name" value={nm} onChange={e=>setNm(e.target.value)} style={iS}/>}<input type="email" placeholder="Email" value={em} onChange={e=>setEm(e.target.value)} style={iS}/><PasswordInput value={pw} onChange={e=>setPw(e.target.value)} placeholder="Password (min 6)" onKeyDown={e=>e.key==="Enter"&&sub()} T={T}/>{err&&<div style={{padding:"10px",borderRadius:12,background:"#E8505014",border:"1px solid #E8505030",color:"#C03040",fontSize:13,textAlign:"left"}}>{err}</div>}<button onClick={sub} disabled={ld} style={{padding:"15px",borderRadius:16,border:"none",background:`linear-gradient(135deg,${T.accent},${T.accent}CC)`,color:"#FFF",fontSize:17,fontFamily:"inherit",fontWeight:700,cursor:ld?"wait":"pointer",opacity:ld?.7:1,boxShadow:`0 4px 16px ${T.accent}30`}}>{ld?"...":isS?"Create Account":"Log In"}</button><button onClick={()=>{setIsS(s=>!s);setErr("");}} style={{padding:"10px",borderRadius:12,border:`1px solid ${T.pillBd}`,background:"transparent",color:T.sub,fontSize:14,fontFamily:"inherit",cursor:"pointer"}}>{isS?"Have account? Log in":"New? Sign up"}</button></div></div></div>);}

// (spaced repetition functions defined above)

// ——— NAMASTE ANIMATION (FIXED: uses array for multi-byte emoji) ———
function NamasteAnim({name,T}){
  const[phase,setPhase]=useState(0);
  const EMOJIS=["👋","🙏","👋"];
  useEffect(()=>{const t1=setTimeout(()=>setPhase(1),600);const t2=setTimeout(()=>setPhase(2),1800);const t3=setTimeout(()=>setPhase(3),2800);return()=>{clearTimeout(t1);clearTimeout(t2);clearTimeout(t3);};},[]);
  if(phase===3)return null;
  return(<div style={{position:"fixed",inset:0,zIndex:150,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.3)",backdropFilter:"blur(8px)",transition:"opacity .4s"}}>
    <div style={{textAlign:"center"}}>
      <div style={{fontSize:72,transition:"all .4s ease",transform:phase===1?"scale(1.2)":"scale(1)"}}>{EMOJIS[phase]}</div>
      <div style={{fontSize:28,fontWeight:800,color:"#FFF",marginTop:12,textShadow:"0 2px 20px rgba(0,0,0,.3)"}}>Namaste, {name}!</div>
    </div>
  </div>);
}

export default function App(){
  const[user,setUser]=useState(null);const[userName,setUserName]=useState("");const[authLoading,setAuthLoading]=useState(true);
  const[activeCategory,setActiveCategory]=useState(null);const[idx,setIdx]=useState(0);const[flipped,setFlipped]=useState(false);
  const[cardLevels,setCardLevels]=useState({});const[anim,setAnim]=useState(false);const[dark,setDark]=useState(false);
  const[autoSpeak,setAutoSpeak]=useState(true);const[saving,setSaving]=useState(false);
  const[tab,setTab]=useState("practice");const[showList,setShowList]=useState(null);
  const[swipeHint,setSwipeHint]=useState(null);const[practiceMode,setPracticeMode]=useState(null);
  const[stats,setStats]=useState({totalMinutes:0,dailyLog:{},dailyTarget:25});
  const[showHint,setShowHint]=useState(false);const[todayFlips,setTodayFlips]=useState(0);
  const[showTutorial,setShowTutorial]=useState(false);const[lang,setLang]=useState("en");
  const[shuffled,setShuffled]=useState(false);const[shuffledCards,setShuffledCards]=useState([]);
  const[showNamaste,setShowNamaste]=useState(false);
  const[authMode,setAuthMode]=useState(null); // null=landing, "signup", "login"
  const[searchQuery,setSearchQuery]=useState("");
  const[favorites,setFavorites]=useState(new Set());
  const[timeOffset,setTimeOffset]=useState(0); // Debug: ms offset to simulate time
  const[showSchedule,setShowSchedule]=useState(false); // Toggle review schedule on card front
  const[nailedCount,setNailedCount]=useState(0); // Counter: increments on every right swipe / Got it
  const[showCatBreakdown,setShowCatBreakdown]=useState(false); // Toggle category breakdown from mastery ring
  // New toggle states for card back info panels
  const[showLatin,setShowLatin]=useState(false);
  const[showGender,setShowGender]=useState(false);
  const[showPlural,setShowPlural]=useState(false);
  const lastActivity=useRef(Date.now());const sessionStart=useRef(Date.now());
  // Ref for tracking marked card to fix Due stuck bug
  const lastMarkedId=useRef(null);

  // ——— PWA Install ———
  const pwa=usePWAInstall();
  const[showIOSModal,setShowIOSModal]=useState(false);
  const[installFeedback,setInstallFeedback]=useState("");

  const handleInstallClick=useCallback(async()=>{
    if(pwa.isInstalled)return;
    if(pwa.isIOS){setShowIOSModal(true);return;}
    if(pwa.canInstall){
      setInstallFeedback(u.installSuccess||"Opening install prompt…");
      const accepted=await pwa.triggerInstall();
      setInstallFeedback(accepted?"✅":"");
      setTimeout(()=>setInstallFeedback(""),3000);
    }
  },[pwa,u]);

  const{speak,stop,speaking,activeSpeed,supported}=useSpeech();
  const T=dark?TD:TL;const u=UI[lang]||UI.en;const today=new Date().toISOString().slice(0,10);
  const lvlNames=[u.new,u.reviewing,u.improving,u.strong,u.master];

  const knownSet=useMemo(()=>new Set(Object.entries(cardLevels).filter(([,v])=>v.level>=5).map(([k])=>+k)),[cardLevels]);
  const learningSet=useMemo(()=>new Set(Object.entries(cardLevels).filter(([,v])=>v.level>=2&&v.level<5).map(([k])=>+k)),[cardLevels]);
  const dueCards=useMemo(()=>ALL_CARDS.filter(c=>isDue(cardLevels,c.id,timeOffset)),[cardLevels,timeOffset]);

  // Calculate current streak (consecutive days meeting daily target)
  const streak=useMemo(()=>{
    const log=stats.dailyLog||{};
    const dt=stats.dailyTarget||25;
    const d=new Date();d.setHours(0,0,0,0);
    // Check if today has met target; if not, start from yesterday
    const todayKey=d.toISOString().slice(0,10);
    if((log[todayKey]||0)<dt){d.setDate(d.getDate()-1);}
    let count=0;
    for(let i=0;i<365;i++){
      const k=d.toISOString().slice(0,10);
      if((log[k]||0)>=dt){count++;d.setDate(d.getDate()-1);}else break;
    }
    return count;
  },[stats.dailyLog,stats.dailyTarget]);

  const baseCards=useMemo(()=>{
    if(practiceMode==="learning")return ALL_CARDS.filter(c=>{const l=getLevel(cardLevels,c.id).level;return l>=2&&l<5&&isDue(cardLevels,c.id,timeOffset);});
    if(practiceMode==="due")return dueCards;
    if(activeCategory==="__fav__")return ALL_CARDS.filter(c=>favorites.has(c.id));
    if(activeCategory==="All")return ALL_CARDS;
    if(activeCategory)return ALL_CARDS.filter(c=>c.cat===activeCategory);
    return[];
  },[activeCategory,practiceMode,cardLevels,dueCards,favorites,timeOffset]);

  const cards=shuffled?shuffledCards:baseCards;
  const card=cards[idx]||cards[0];const color=CC[card?.cat]||"#4A8EC2";
  const catName=c=>lang==="de"?(CAT_DE[c]||c):c;
  const cardFront=lang==="de"?(card?.frontDe||card?.front):card?.front;
  const cardHint=lang==="de"?(card?.hintDe||card?.hint):card?.hint;
  const exLang=lang==="de"?(card?.example?.de||card?.example?.en):card?.example?.en;
  const markActive=useCallback(()=>{lastActivity.current=Date.now();},[]);

  // Clamp idx when filtered list shrinks (prevents skip bug)
  useEffect(()=>{if(cards.length>0&&idx>=cards.length)setIdx(Math.max(0,cards.length-1));},[cards.length,idx]);

  // FIX: After marking a card in practiceMode, if the same card is still showing, advance
  useEffect(()=>{
    if(practiceMode&&lastMarkedId.current!==null&&cards.length>0){
      const currentCard=cards[idx]||cards[0];
      if(currentCard&&currentCard.id===lastMarkedId.current){
        // Card is still in the list after marking — advance
        lastMarkedId.current=null;
        setFlipped(false);setShowHint(false);setShowLatin(false);setShowGender(false);setShowPlural(false);
        setIdx(i=>{const n=i+1;return n>=cards.length?0:n;});
      } else {
        lastMarkedId.current=null;
      }
    }
  },[cardLevels,practiceMode,cards,idx]);

  // Reset info toggles when card changes
  useEffect(()=>{setShowLatin(false);setShowGender(false);setShowPlural(false);setShowSchedule(false);},[idx]);

  useEffect(()=>{const unsub=onAuthStateChanged(auth,async usr=>{setUser(usr);if(usr){const d=await loadData(usr.uid);if(d){setCardLevels(d.cardLevels||{});setUserName(d.name||"");setStats(d.stats||{totalMinutes:0,dailyLog:{},dailyTarget:25});setTodayFlips(d.stats?.dailyLog?.[today]||0);setLang(d.lang||"en");if(d.favorites)setFavorites(new Set(d.favorites));if(d.nailedCount)setNailedCount(d.nailedCount);if(d.showTutorial)setShowTutorial(true);}setShowNamaste(true);}setAuthLoading(false);});return()=>unsub();},[]);

  useEffect(()=>{if(!user)return;const iv=setInterval(()=>{if(Date.now()-lastActivity.current<60000){const el=(Date.now()-sessionStart.current)/60000;if(el>0&&el<2)setStats(p=>({...p,totalMinutes:(p.totalMinutes||0)+el}));}sessionStart.current=Date.now();},30000);return()=>clearInterval(iv);},[user]);

  const saveTimeout=useRef(null);
  useEffect(()=>{if(!user)return;if(saveTimeout.current)clearTimeout(saveTimeout.current);saveTimeout.current=setTimeout(async()=>{setSaving(true);await saveData(user.uid,{name:userName,cardLevels,stats,lang,favorites:[...favorites],nailedCount,showTutorial:false});setSaving(false);},1000);return()=>{if(saveTimeout.current)clearTimeout(saveTimeout.current);};},[cardLevels,user,userName,stats,lang,favorites,nailedCount]);

  const speakText=card?.speakAs||card?.back;
  const prevFlipped=useRef(false);
  useEffect(()=>{if(flipped&&!prevFlipped.current){if(autoSpeak&&supported&&card)setTimeout(()=>speak(speakText,.75,"normal"),400);}prevFlipped.current=flipped;},[flipped,card,autoSpeak,supported,speak,speakText]);

  const doFlip=useCallback(()=>{if(!anim){setFlipped(f=>!f);setShowHint(false);markActive();}},[anim,markActive]);
  const nav=useCallback(d=>{if(anim)return;setAnim(true);setFlipped(false);setShowHint(false);setShowLatin(false);setShowGender(false);setShowPlural(false);stop();markActive();setTimeout(()=>{setIdx(i=>{const n=i+d;return n<0?cards.length-1:n>=cards.length?0:n;});setAnim(false);},200);},[cards.length,anim,stop,markActive]);

  // DUE BUG FIX: track marked card id so useEffect can advance if card stays in list
  const markKnow=useCallback(()=>{if(!card)return;markActive();lastMarkedId.current=card.id;setCardLevels(p=>lvlUp(p,card.id,timeOffset));setNailedCount(n=>n+1);setTodayFlips(f=>f+1);setStats(p=>({...p,dailyLog:{...p.dailyLog,[today]:(p.dailyLog?.[today]||0)+1}}));if(practiceMode){setFlipped(false);setShowHint(false);setShowLatin(false);setShowGender(false);setShowPlural(false);stop();}else nav(1);},[card,nav,markActive,practiceMode,stop,timeOffset,today]);
  const markLearn=useCallback(()=>{if(!card)return;markActive();lastMarkedId.current=card.id;setCardLevels(p=>lvlDown(p,card.id,timeOffset));setTodayFlips(f=>f+1);setStats(p=>({...p,dailyLog:{...p.dailyLog,[today]:(p.dailyLog?.[today]||0)+1}}));if(practiceMode){setFlipped(false);setShowHint(false);setShowLatin(false);setShowGender(false);setShowPlural(false);stop();}else nav(1);},[card,nav,markActive,practiceMode,stop,timeOffset,today]);

  const onSwipeL=useCallback(()=>{setSwipeHint("left");setTimeout(()=>setSwipeHint(null),400);markLearn();},[markLearn]);
  const onSwipeR=useCallback(()=>{setSwipeHint("right");setTimeout(()=>setSwipeHint(null),400);markKnow();},[markKnow]);
  const swipe=useSwipe(onSwipeL,onSwipeR);
  const handleLogout=async()=>{stop();await signOut(auth);setAuthMode(null);};
  const pct=Math.round((knownSet.size/ALL_CARDS.length)*100);
  const handlePlay=(e,sp)=>{e.stopPropagation();markActive();if(speaking&&activeSpeed===sp.key){stop();return;}speak(speakText,sp.rate,sp.key);};
  const displayName=userName||user?.email?.split("@")[0]||"Learner";
  const jumpToCard=id=>{setPracticeMode(null);setActiveCategory("All");setShuffled(false);setFlipped(false);setShowHint(false);stop();const i=ALL_CARDS.findIndex(c=>c.id===id);if(i>=0)setIdx(i);setShowList(null);setTab("practice");};
  const exitPractice=()=>{setPracticeMode(null);setActiveCategory(null);setShuffled(false);setIdx(0);setFlipped(false);setShowHint(false);};
  const goBackToGrid=()=>{setActiveCategory(null);setShuffled(false);setIdx(0);setFlipped(false);setShowHint(false);stop();setSearchQuery("");};
  const toggleFav=useCallback((id)=>{setFavorites(prev=>{const n=new Set(prev);if(n.has(id))n.delete(id);else n.add(id);return n;});},[]);
  const favCards=useMemo(()=>ALL_CARDS.filter(c=>favorites.has(c.id)),[favorites]);
  const searchResults=useMemo(()=>{if(!searchQuery.trim())return[];const q=searchQuery.toLowerCase();return ALL_CARDS.filter(c=>c.front.toLowerCase().includes(q)||c.frontDe.toLowerCase().includes(q)||c.back.includes(q)||c.tl.toLowerCase().includes(q));},[searchQuery]);
  const enterCategory=cat=>{setActiveCategory(cat);setIdx(0);setFlipped(false);setShowHint(false);setSearchQuery("");
    const catCards=cat==="All"?ALL_CARDS:ALL_CARDS.filter(c=>c.cat===cat);
    setShuffledCards(shuffleArr(catCards));setShuffled(true);
  };
  const doShuffle=()=>{setShuffledCards(shuffleArr(baseCards));setShuffled(true);setIdx(0);setFlipped(false);};
  const dailyTarget=stats.dailyTarget||25;const targetPct=Math.min(Math.round((todayFlips/dailyTarget)*100),100);
  const cl=card?getLevel(cardLevels,card.id):{level:1};
  const speakEx=e=>{e.stopPropagation();markActive();if(card?.example)speak(card.example.hi,.75,"normal");};
  const closeTutorial=()=>{setShowTutorial(false);if(user)saveData(user.uid,{showTutorial:false});};
  const inCardView=activeCategory!==null||practiceMode;

  // Helper: does this card have gender/plural/genderForms info?
  const hasGenderInfo=card&&(card.gender||card.gf);
  const hasPluralInfo=card&&card.plural;
  const hasLatinInfo=card&&card.tl;

  // Toggle button style helper
  const toggleBtnStyle=(active)=>({
    padding:"5px 10px",borderRadius:10,
    border:`1.5px solid ${active?color+"60":T.pillBd}`,
    background:active?`${color}14`:T.speedBg,
    color:active?color:T.sub,
    cursor:"pointer",fontSize:12,fontFamily:"inherit",fontWeight:600,
    display:"flex",alignItems:"center",gap:3
  });

  if(authLoading)return(<div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"linear-gradient(170deg,#F6F9FC 0%,#EDF2F8 25%,#E8EEF6 50%,#E4F0F4 75%,#F2F6FA 100%)",fontFamily:"'Outfit',sans-serif"}}><link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap" rel="stylesheet"/><div style={{textAlign:"center",color:T.muted}}><div style={{fontSize:40,marginBottom:12}}>🇮🇳</div><div style={{fontSize:18,fontWeight:600}}>Loading...</div></div></div>);
  if(!user){
    if(authMode==="signup")return <AuthScreen T={TL} onBack={()=>setAuthMode(null)} initialMode="signup"/>;
    if(authMode==="login")return <AuthScreen T={TL} onBack={()=>setAuthMode(null)} initialMode="login"/>;
    return <LandingPage onStart={()=>setAuthMode("signup")} onLogin={()=>setAuthMode("login")}/>;
  }

  return(
    <div style={{minHeight:"100vh",background:T.bgGrad,fontFamily:"'Outfit',sans-serif",color:T.text,display:"flex",flexDirection:"column",alignItems:"center",padding:"14px 14px 80px",boxSizing:"border-box",transition:"background .4s"}}>
      <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap" rel="stylesheet"/>
      <style>{`@keyframes speakPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}@keyframes barBounce{0%,100%{transform:scaleY(.3)}50%{transform:scaleY(1)}}@keyframes swL{0%{opacity:0;transform:translateX(20px)}50%{opacity:1}100%{opacity:0;transform:translateX(-20px)}}@keyframes swR{0%{opacity:0;transform:translateX(-20px)}50%{opacity:1}100%{opacity:0;transform:translateX(20px)}}@keyframes hintIn{from{opacity:0;max-height:0}to{opacity:1;max-height:200px}}@keyframes todayPulse{0%,100%{box-shadow:0 0 0 0 rgba(74,142,194,.4)}50%{box-shadow:0 0 0 4px rgba(74,142,194,.15)}}.cat-tile{transition:transform .2s ease,box-shadow .2s ease}.cat-tile:hover{transform:translateY(-3px);box-shadow:0 6px 24px rgba(0,0,0,.08)!important}.cat-tile:active{transform:scale(.97)}*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0}`}</style>

      {showNamaste&&<NamasteAnim name={displayName} T={T}/>}
      {showTutorial&&<TutorialModal T={T} onDone={closeTutorial}/>}

      {/* ——— iOS Install Instructions Modal ——— */}
      {showIOSModal&&<div style={{position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.5)",padding:20,boxSizing:"border-box"}} onClick={()=>setShowIOSModal(false)}>
        <div onClick={e=>e.stopPropagation()} style={{background:T.overlayBg,borderRadius:28,padding:"32px 24px 24px",width:"100%",maxWidth:380,textAlign:"center",boxShadow:"0 20px 60px rgba(0,0,0,.2)",backdropFilter:"blur(20px)"}}>
          <div style={{fontSize:48,marginBottom:8}}>📲</div>
          <h2 style={{fontSize:22,fontWeight:800,color:T.text,margin:"0 0 16px"}}>{u.iosInstTitle}</h2>
          <div style={{textAlign:"left",margin:"0 auto",maxWidth:300}}>
            <div style={{display:"flex",alignItems:"flex-start",gap:10,marginBottom:14}}>
              <span style={{fontSize:22,lineHeight:1,flexShrink:0}}>1️⃣</span>
              <span style={{fontSize:15,color:T.sub,lineHeight:1.5}}>{u.iosInst1} <span style={{fontSize:20,verticalAlign:"middle"}}>⎋</span></span>
            </div>
            <div style={{display:"flex",alignItems:"flex-start",gap:10,marginBottom:14}}>
              <span style={{fontSize:22,lineHeight:1,flexShrink:0}}>2️⃣</span>
              <span style={{fontSize:15,color:T.sub,lineHeight:1.5}}>{u.iosInst2}</span>
            </div>
            <div style={{display:"flex",alignItems:"flex-start",gap:10,marginBottom:14}}>
              <span style={{fontSize:22,lineHeight:1,flexShrink:0}}>3️⃣</span>
              <span style={{fontSize:15,color:T.sub,lineHeight:1.5}}>{u.iosInst3}</span>
            </div>
          </div>
          <div style={{fontSize:13,color:T.muted,marginTop:8,marginBottom:16}}>{u.iosInstDone}</div>
          <button onClick={()=>setShowIOSModal(false)} style={{padding:"12px 24px",borderRadius:14,border:"none",background:`linear-gradient(135deg,${T.accent},${T.accent}DD)`,color:"#FFF",fontSize:15,fontFamily:"inherit",fontWeight:700,cursor:"pointer",width:"100%"}}>OK</button>
        </div>
      </div>}

      {showList&&<div style={{position:"fixed",inset:0,zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.4)",padding:20}} onClick={()=>setShowList(null)}><div onClick={e=>e.stopPropagation()} style={{background:T.overlayBg,borderRadius:24,padding:"24px 20px",width:"100%",maxWidth:440,maxHeight:"85vh",overflowY:"auto",boxShadow:"0 20px 60px rgba(0,0,0,.2)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}><h2 style={{fontSize:20,fontWeight:800,color:T.text,margin:0}}>{showList==="known"?`⭐ ${u.mastered}`:`📖 ${u.learning}`} ({(showList==="known"?knownSet:learningSet).size})</h2><button onClick={()=>setShowList(null)} style={{width:34,height:34,borderRadius:"50%",border:`1px solid ${T.pillBd}`,background:T.btnBg,color:T.btnTx,cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button></div>
        {ALL_CARDS.filter(c=>(showList==="known"?knownSet:learningSet).has(c.id)).map(c=>{const lv=getLevel(cardLevels,c.id);const front=lang==="de"?(c.frontDe||c.front):c.front;return(<button key={c.id} onClick={()=>jumpToCard(c.id)} style={{width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 14px",borderRadius:14,border:`1px solid ${T.pillBd}`,background:T.pillBg,marginBottom:6,cursor:"pointer",textAlign:"left",fontFamily:"inherit"}}><div><div style={{fontSize:15,fontWeight:700,color:T.text}}>{front}</div><div style={{fontSize:13,color:CC[c.cat],fontWeight:600,marginTop:1}}>{c.back} · {c.tl}</div></div><span style={{fontSize:10,fontWeight:700,color:LVL_C[lv.level-1],background:`${LVL_C[lv.level-1]}15`,padding:"2px 7px",borderRadius:6}}>Lv{lv.level}</span></button>);})}
      </div></div>}

      <div style={{position:"relative",zIndex:1,width:"100%",maxWidth:560}}>
        {tab==="practice"&&<>
          <div style={{marginBottom:4}}><div style={{fontSize:13,letterSpacing:3,color:T.accent,fontWeight:700,marginBottom:2,fontFamily:"'Noto Sans Devanagari',sans-serif"}}>हिंदी सीखें</div><h1 style={{fontSize:24,fontWeight:800,margin:0,color:T.text}}>Namaste, {displayName}!</h1></div>
          {!inCardView&&<div style={{marginBottom:10}}><input type="text" placeholder={`🔍 ${u.search}`} value={searchQuery} onChange={e=>setSearchQuery(e.target.value)} style={{width:"100%",padding:"11px 16px",borderRadius:14,border:`1.5px solid ${T.inputBd}`,background:T.inputBg,color:T.text,fontSize:14,fontFamily:"'Outfit',sans-serif",outline:"none",boxSizing:"border-box"}}/></div>}
          <div style={{marginBottom:8,padding:"8px 14px",borderRadius:14,background:T.pillBg,border:`1px solid ${T.pillBd}`,boxShadow:T.catCardShadow}}><div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:4}}><span style={{fontWeight:600,color:T.text}}>🎯 {todayFlips}/{dailyTarget} {u.flips}</span><span style={{fontWeight:700,color:targetPct>=100?"#40A050":T.accent}}>{targetPct>=100?u.done:`${targetPct}%`}</span></div><div style={{height:5,borderRadius:3,background:T.dotBg,overflow:"hidden"}}><div style={{height:"100%",borderRadius:3,width:`${targetPct}%`,background:targetPct>=100?"linear-gradient(90deg,#40A050,#80B050)":"linear-gradient(90deg,#D06060,#C8A040)",transition:"width .4s"}}/></div></div>
          {practiceMode&&<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 14px",borderRadius:12,background:"#C8A04014",border:"1.5px solid #C8A04030",marginBottom:8}}><span style={{fontSize:13,fontWeight:700,color:"#C8A040"}}>🎯 {practiceMode==="learning"?u.pracLearn:u.pracDue}: {cards.length}</span><button onClick={exitPractice} style={{padding:"5px 10px",borderRadius:10,border:"1px solid #C8A04040",background:"transparent",color:"#C8A040",fontSize:11,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>{u.exit}</button></div>}

          {!inCardView&&<>
            {searchQuery.trim()&&<div style={{marginBottom:14}}>{searchResults.length===0?<div style={{textAlign:"center",padding:20,color:T.muted}}>{u.noResults}</div>:searchResults.slice(0,20).map(c=>{const front=lang==="de"?(c.frontDe||c.front):c.front;const isFav=favorites.has(c.id);return(<button key={c.id} onClick={()=>{jumpToCard(c.id);setSearchQuery("");}} style={{width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 14px",borderRadius:14,border:`1px solid ${T.pillBd}`,background:T.pillBg,marginBottom:6,cursor:"pointer",textAlign:"left",fontFamily:"inherit"}}><div style={{flex:1}}><div style={{fontSize:15,fontWeight:700,color:T.text}}>{front}</div><div style={{fontSize:13,color:CC[c.cat],fontWeight:600,marginTop:1}}>{c.back} · {c.tl}</div></div><button onClick={e=>{e.stopPropagation();toggleFav(c.id);}} style={{background:"none",border:"none",fontSize:18,cursor:"pointer",padding:4,color:isFav?"#E25555":"#CCC"}}>{isFav?"❤️":"🤍"}</button></button>);})}</div>}
            {!searchQuery.trim()&&<>
            {/* ——— Browse All + Due ——— */}
            <div style={{display:"flex",gap:8,marginBottom:10}}>
              <button onClick={()=>enterCategory("All")} style={{flex:1,padding:"14px 12px",borderRadius:16,border:"none",background:`${T.accent}0C`,cursor:"pointer",fontFamily:"inherit",display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
                <span style={{fontSize:22}}>📚</span>
                <span style={{fontSize:15,fontWeight:700,color:T.text}}>{u.browseAll}</span>
                <span style={{fontSize:12,color:T.muted,fontWeight:500}}>{ALL_CARDS.length} {lang==="de"?"Karten":"cards"} · 🔀</span>
              </button>
              {dueCards.length>0&&<button onClick={()=>{setPracticeMode("due");setShuffledCards(shuffleArr(dueCards));setShuffled(true);setIdx(0);}} style={{flex:1,padding:"14px 12px",borderRadius:16,border:"none",background:"#D060600C",cursor:"pointer",fontFamily:"inherit",display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
                <span style={{fontSize:22}}>🔥</span>
                <span style={{fontSize:15,fontWeight:700,color:"#D06060"}}>{dueCards.length} {u.due}</span>
                <span style={{fontSize:12,color:T.muted,fontWeight:500}}>{lang==="de"?"Jetzt üben":"Practice now"} · 🔀</span>
              </button>}
            </div>
            <div style={{fontSize:13,fontWeight:700,color:T.muted,textTransform:"uppercase",letterSpacing:1.5,marginBottom:8,padding:"0 2px"}}>{u.cats}</div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10,marginBottom:12}}>
              {CATEGORIES.filter(c=>c!=="All").map(cat=>{const cc=CC[cat]||T.accent;const catCards=ALL_CARDS.filter(c=>c.cat===cat);return(<button key={cat} className="cat-tile" onClick={()=>enterCategory(cat)} style={{padding:"16px 14px",borderRadius:18,border:`1px solid ${T.catCardBd}`,borderLeft:`4px solid ${cc}`,background:T.catCardBg,boxShadow:T.catCardShadow,cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",alignItems:"center",gap:12}}>
                <div style={{width:40,height:40,borderRadius:12,background:`${cc}14`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{CAT_EMOJI[cat]||"📁"}</div>
                <div><div style={{fontSize:15,fontWeight:600,color:T.text,lineHeight:1.2}}>{catName(cat)}</div><div style={{fontSize:12,color:T.muted,marginTop:2}}>{catCards.length} {lang==="de"?"Karten":"cards"}</div></div>
              </button>);})}
            </div>

            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,padding:"12px 0",borderTop:`1px solid ${T.divider}`}}>{[{l:u.fav,v:favCards.length,c:"#E25555",i:"❤️",cl:()=>{if(favCards.length){setActiveCategory("__fav__");setIdx(0);setFlipped(false);setShowHint(false);setShuffledCards(shuffleArr(favCards));setShuffled(true);}}},{l:lang==="de"?"Am Lernen":"In progress",v:learningSet.size,c:"#C8A040",i:"📖",cl:()=>setShowList("learning")},{l:lang==="de"?"Richtig":"Nailed",v:nailedCount,c:"#40A050",i:"⭐",cl:()=>{}},{l:u.due,v:dueCards.length,c:"#D06060",i:"🔥",cl:()=>{setPracticeMode("due");setShuffledCards(shuffleArr(dueCards));setShuffled(true);setIdx(0);}}].map(s=>(<div key={s.l} onClick={s.cl} style={{padding:"10px 4px",borderRadius:14,background:`${s.c}08`,cursor:s.cl?"pointer":"default",display:"flex",flexDirection:"column",alignItems:"center",gap:4}}><div style={{display:"flex",alignItems:"center",gap:4}}><span style={{fontSize:18}}>{s.i}</span><span style={{fontSize:20,fontWeight:800,color:s.c}}>{s.v}</span></div><span style={{fontSize:13,color:T.sub,fontWeight:700,textAlign:"center",lineHeight:1.2}}>{s.l}</span></div>))}</div>
            </>}
          </>}

          {inCardView&&cards.length>0&&<>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}><button onClick={practiceMode?exitPractice:goBackToGrid} style={{display:"flex",alignItems:"center",gap:6,padding:"10px 18px",borderRadius:14,border:`2px solid ${T.accent}40`,background:`${T.accent}10`,color:T.accent,fontSize:15,fontFamily:"inherit",fontWeight:700,cursor:"pointer",boxShadow:`0 2px 8px ${T.accent}15`}}>← {u.back}</button><div style={{display:"flex",alignItems:"center",gap:6}}><span style={{fontSize:13,color,fontWeight:700}}>{!practiceMode&&activeCategory!=="All"&&activeCategory!=="__fav__"?catName(activeCategory)+" · ":""}{activeCategory==="__fav__"?(u.fav+" · "):""}{idx+1}/{cards.length}</span><button onClick={doShuffle} style={{padding:"6px 12px",borderRadius:12,border:`1.5px solid ${T.accent}40`,background:`${T.accent}12`,color:T.accent,fontSize:12,fontFamily:"inherit",fontWeight:700,cursor:"pointer",display:"flex",alignItems:"center",gap:4}}>🔀 {u.shuffle}</button></div></div>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:6,padding:"0 2px"}}><div style={{display:"flex",gap:3}}>{[1,2,3,4,5].map(l=>(<div key={l} style={{width:8,height:8,borderRadius:"50%",background:cl.level>=l?LVL_C[l-1]:T.dotBg}}/>))}</div><span style={{fontSize:12,fontWeight:700,color:LVL_C[cl.level-1]}}>{lvlNames[cl.level-1]}</span></div>

            <div {...swipe} onClick={doFlip} style={{perspective:1200,cursor:"pointer",marginBottom:8,height:450,position:"relative"}}>
              {swipeHint==="right"&&<div style={{position:"absolute",inset:0,zIndex:10,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:24,background:"rgba(64,160,80,.12)",animation:"swR .4s ease-out forwards",pointerEvents:"none"}}><span style={{fontSize:44}}>✅</span></div>}
              {swipeHint==="left"&&<div style={{position:"absolute",inset:0,zIndex:10,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:24,background:"rgba(200,160,64,.12)",animation:"swL .4s ease-out forwards",pointerEvents:"none"}}><span style={{fontSize:44}}>🔄</span></div>}
              <div style={{position:"relative",width:"100%",height:"100%",transformStyle:"preserve-3d",transform:flipped?"rotateY(180deg)":"rotateY(0)",transition:"transform .65s cubic-bezier(.23,1,.32,1)"}}>
                {/* ——— FRONT SIDE ——— */}
                <div style={{position:"absolute",inset:0,backfaceVisibility:"hidden",WebkitBackfaceVisibility:"hidden",borderRadius:24,background:T.cardFront,border:`1px solid ${color}18`,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"28px 22px",boxShadow:T.cardShadow}}>
                  <div style={{position:"absolute",top:14,left:16,display:"flex",alignItems:"center",gap:6}}>
                    <span style={{fontSize:10,fontWeight:700,color:LVL_C[cl.level-1],background:`${LVL_C[cl.level-1]}18`,padding:"2px 8px",borderRadius:8}}>Lv{cl.level}</span>
                    <button onClick={e=>{e.stopPropagation();setShowSchedule(v=>!v);}} style={{background:"none",border:"none",cursor:"pointer",fontSize:14,padding:2,color:showSchedule?T.accent:T.muted,opacity:.7}}>🕐</button>
                  </div>
                  <div style={{position:"absolute",top:14,right:16,fontSize:12,color:T.muted,letterSpacing:1.5,textTransform:"uppercase",fontWeight:600}}>{lang==="de"?"Deutsch":"English"}</div>
                  {showSchedule&&<div onClick={e=>e.stopPropagation()} style={{position:"absolute",top:38,left:14,right:14,padding:"8px 12px",borderRadius:12,background:T.hintBg,border:`1px solid ${T.hintBd}`,animation:"hintIn .3s ease-out",zIndex:5}}>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:T.sub,lineHeight:1.8}}>
                      <span>Level: <b style={{color:LVL_C[cl.level-1]}}>{cl.level}/5</b></span>
                      <span>Interval: <b>{LVL_LABELS_SHORT[cl.level-1]}</b></span>
                    </div>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:T.sub,lineHeight:1.8}}>
                      <span>Reviewed: <b>{cl.lastReviewedAt?new Date(cl.lastReviewedAt).toLocaleDateString():"Never"}</b></span>
                      <span>Next: <b style={{color:isDue(cardLevels,card?.id,timeOffset)?"#D06060":"#40A050"}}>{fmtRelTime(cl.nextReviewAt,timeOffset)}</b></span>
                    </div>
                    {timeOffset>0&&<div style={{fontSize:10,color:T.accent,marginTop:2,textAlign:"center"}}>⏩ Debug: +{Math.round(timeOffset/36e5)}h offset</div>}
                  </div>}
                  <div style={{fontSize:cardFront&&cardFront.length>20?26:42,fontWeight:800,textAlign:"center",lineHeight:1.25,color:T.text}}>{cardFront}</div>
                  <div style={{marginTop:14,width:"100%",maxWidth:360,textAlign:"center"}}>{!showHint?<button onClick={e=>{e.stopPropagation();setShowHint(true);markActive();}} style={{padding:"8px 18px",borderRadius:14,border:`1.5px solid ${T.hintBd}`,background:T.hintBg,color:T.hintTx,fontSize:14,fontFamily:"inherit",fontWeight:600,cursor:"pointer",margin:"0 auto",display:"flex",alignItems:"center",gap:6}}>💡 {u.hint}</button>:<div style={{animation:"hintIn .3s ease-out",padding:"10px 16px",borderRadius:14,background:T.hintBg,border:`1.5px solid ${T.hintBd}`,fontSize:14,color:T.hintTx,lineHeight:1.5,fontWeight:500}} onClick={e=>e.stopPropagation()}>{cardHint}</div>}</div>
                  <div style={{marginTop:14,fontSize:13,color:T.faint}}>{u.flipHint}</div>
                </div>
                {/* ——— BACK SIDE ——— */}
                <div style={{position:"absolute",inset:0,backfaceVisibility:"hidden",WebkitBackfaceVisibility:"hidden",transform:"rotateY(180deg)",borderRadius:24,background:dark?`linear-gradient(155deg,${color}10,#1A1620 25%,#161420)`:`linear-gradient(155deg,${color}06,#FFF 25%,#F8F6F3)`,border:`1px solid ${color}${dark?"28":"14"}`,display:"flex",flexDirection:"column",alignItems:"center",padding:"12px 14px",boxShadow:T.cardShadow,overflowY:"auto",justifyContent:"flex-start",paddingTop:32}}>
                  <div style={{position:"absolute",top:10,right:14,display:"flex",alignItems:"center",gap:8}}>
                    <button onClick={e=>{e.stopPropagation();if(card)toggleFav(card.id);}} style={{background:"none",border:"none",fontSize:18,cursor:"pointer",padding:2,color:card&&favorites.has(card.id)?"#E25555":"#CCC"}}>{card&&favorites.has(card.id)?"❤️":"🤍"}</button>
                    <span style={{fontSize:11,color,letterSpacing:1.5,textTransform:"uppercase",fontWeight:700,opacity:.7,fontFamily:"'Noto Sans Devanagari',sans-serif"}}>हिंदी</span>
                  </div>
                  {/* Hindi word */}
                  <div style={{fontFamily:"'Noto Sans Devanagari',sans-serif",fontSize:card?.back.length>14?28:46,fontWeight:700,textAlign:"center",color:T.text,lineHeight:1.3,whiteSpace:"pre-line"}}>{card?.back}</div>
                  {/* Audio controls */}
                  {supported&&<div onClick={e=>e.stopPropagation()} style={{marginTop:8,padding:"4px",borderRadius:14,background:T.speedBg,border:`1px solid ${T.speedBd}`,display:"flex",gap:4,width:"100%",maxWidth:400}}>{SPEEDS.map(sp=>{const isA=speaking&&activeSpeed===sp.key;return(<button key={sp.key} onClick={e=>handlePlay(e,sp)} style={{flex:1,padding:"8px",borderRadius:10,border:"1.5px solid",borderColor:isA?`${color}60`:"transparent",background:isA?T.speedActive:"transparent",color:isA?color:T.sub,cursor:"pointer",fontSize:14,fontFamily:"inherit",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:4,animation:isA?"speakPulse 1.2s ease-in-out infinite":"none"}}>{isA?<div style={{display:"flex",gap:2,height:14}}>{[0,1,2,3].map(b=><div key={b} style={{width:3,height:14,borderRadius:2,background:color,animation:`barBounce 0.${5+b*2}s ease-in-out infinite`,animationDelay:`${b*.1}s`}}/>)}</div>:<span>{sp.emoji}</span>}{sp.label}</button>);})}</div>}
                  {/* ——— Toggle buttons row: Latin / Gender / Plural ——— */}
                  <div onClick={e=>e.stopPropagation()} style={{display:"flex",gap:5,marginTop:6,flexWrap:"wrap",justifyContent:"center"}}>
                    {hasLatinInfo&&<button onClick={()=>setShowLatin(v=>!v)} style={toggleBtnStyle(showLatin)}>🔤 {lang==="de"?"Latein":"Latin"}</button>}
                    {hasGenderInfo&&<button onClick={()=>setShowGender(v=>!v)} style={toggleBtnStyle(showGender)}>♂♀ {lang==="de"?"Geschlecht":"Gender"}</button>}
                    {hasPluralInfo&&<button onClick={()=>setShowPlural(v=>!v)} style={toggleBtnStyle(showPlural)}>1⇄2 {lang==="de"?"Singular/Plural":"Singular/Plural"}</button>}
                  </div>
                  {/* Latin transliteration (collapsible) */}
                  {showLatin&&hasLatinInfo&&<div style={{marginTop:5,padding:"5px 12px",borderRadius:10,background:T.pronBg,border:`1px solid ${T.pronBd}`,fontSize:14,color,fontWeight:500,width:"100%",maxWidth:400,textAlign:"center",animation:"hintIn .3s ease-out"}}>🔤 {card.tl}</div>}
                  {/* Gender info (collapsible) */}
                  {showGender&&hasGenderInfo&&<div style={{marginTop:5,padding:"5px 12px",borderRadius:10,background:T.pronBg,border:`1px solid ${T.pronBd}`,fontSize:13,color,fontWeight:500,width:"100%",maxWidth:400,textAlign:"center",animation:"hintIn .3s ease-out",lineHeight:1.5}}>
                    {card.gender&&<span>♂♀ {card.gender==="m"?(lang==="de"?"Maskulin (पुल्लिंग)":"Masculine (पुल्लिंग)"):(lang==="de"?"Feminin (स्त्रीलिंग)":"Feminine (स्त्रीलिंग)")}</span>}
                    {card.gf&&<span>{card.gender?" · ":""}✨ {card.gf}</span>}
                  </div>}
                  {/* Plural info (collapsible) */}
                  {showPlural&&hasPluralInfo&&<div style={{marginTop:5,padding:"5px 12px",borderRadius:10,background:T.pronBg,border:`1px solid ${T.pronBd}`,fontSize:13,color,fontWeight:500,width:"100%",maxWidth:400,textAlign:"center",animation:"hintIn .3s ease-out",lineHeight:1.5}}>
                    <span style={{fontFamily:"'Noto Sans Devanagari',sans-serif"}}>1⇄2 {lang==="de"?"Einzahl":"Singular"}: {card.back} → {lang==="de"?"Mehrzahl":"Plural"}: {card.plural}</span>
                  </div>}
                  {/* German memory trick */}
                  <div style={{marginTop:5,padding:"6px 12px",borderRadius:10,background:T.trickBg,border:`1px solid ${T.trickBd}`,fontSize:13,color:T.trickTx,lineHeight:1.5,textAlign:"center",width:"100%",maxWidth:400,fontWeight:500}}>🇩🇪 {card?.trick}</div>
                  {/* Example sentence */}
                  {card?.example&&<div onClick={e=>e.stopPropagation()} style={{marginTop:5,padding:"8px 12px",borderRadius:10,background:T.exBg,border:`1px solid ${T.exBd}`,width:"100%",maxWidth:400}}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><span style={{fontSize:11,fontWeight:700,color:T.exTx}}>{u.example}</span>{supported&&<button onClick={speakEx} style={{padding:"3px 8px",borderRadius:8,border:`1px solid ${T.exBd}`,background:"transparent",color:T.exTx,fontSize:11,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>{u.play}</button>}</div><div style={{fontFamily:"'Noto Sans Devanagari',sans-serif",fontSize:15,fontWeight:600,color:T.text,lineHeight:1.4}}>{card.example.hi}</div><div style={{fontSize:12,color:T.exTx,marginTop:1}}>{card.example.tl}</div><div style={{fontSize:12,color:T.muted,marginTop:1}}>{exLang}</div></div>}
                </div>
              </div>
            </div>
            <div style={{display:"flex",gap:8,justifyContent:"center",alignItems:"center",marginBottom:10}}><button onClick={()=>nav(-1)} style={{width:52,height:52,borderRadius:"50%",border:`2px solid ${T.btnBd}`,background:T.btnBg,color:T.text,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,fontWeight:700,fontFamily:"inherit",boxShadow:T.catCardShadow}}>‹</button><button onClick={markLearn} style={{padding:"12px 18px",borderRadius:16,border:`2px solid #C8A04040`,background:"#C8A04010",color:"#C8A040",cursor:"pointer",fontSize:14,fontFamily:"inherit",fontWeight:700}}>{u.still}</button><button onClick={markKnow} style={{padding:"12px 18px",borderRadius:16,border:`2px solid #40A05040`,background:"#40A05010",color:"#40A050",cursor:"pointer",fontSize:14,fontFamily:"inherit",fontWeight:700}}>{u.gotIt}</button><button onClick={()=>nav(1)} style={{width:52,height:52,borderRadius:"50%",border:`2px solid ${T.btnBd}`,background:T.btnBg,color:T.text,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,fontWeight:700,fontFamily:"inherit",boxShadow:T.catCardShadow}}>›</button></div>
          </>}
          {inCardView&&cards.length===0&&<div style={{textAlign:"center",padding:"60px 20px",color:T.muted}}><div style={{fontSize:40,marginBottom:12}}>🎉</div><div style={{fontSize:18,fontWeight:600}}>{u.allDone}</div><button onClick={exitPractice} style={{marginTop:16,padding:"12px 24px",borderRadius:16,border:`1.5px solid ${T.accent}40`,background:`${T.accent}10`,color:T.accent,fontSize:15,fontFamily:"inherit",fontWeight:700,cursor:"pointer"}}>{u.back}</button></div>}
        </>}

        {tab==="progress"&&<div>
          <h2 style={{fontSize:24,fontWeight:800,color:T.text,margin:"0 0 14px"}}>📊 {u.progress}</h2>
          {/* ——— Mastery ring (clickable → shows categories) ——— */}
          <div onClick={()=>setShowCatBreakdown(v=>!v)} style={{display:"flex",alignItems:"center",gap:18,padding:"18px 16px",borderRadius:20,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:14,boxShadow:T.catCardShadow,cursor:"pointer",transition:"all .2s"}}><div style={{position:"relative",width:80,height:80,flexShrink:0}}><svg width="80" height="80" viewBox="0 0 80 80"><circle cx="40" cy="40" r="34" fill="none" stroke={T.dotBg} strokeWidth="7"/><circle cx="40" cy="40" r="34" fill="none" stroke={T.accent} strokeWidth="7" strokeDasharray={`${pct*2.14} ${214-pct*2.14}`} strokeDashoffset="54" strokeLinecap="round"/></svg><div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:800,color:T.accent}}>{pct}%</div></div><div style={{flex:1}}><div style={{fontSize:13,fontWeight:600,color:T.muted,textTransform:"uppercase",letterSpacing:1,marginBottom:2}}>{u.mastery}</div><div style={{fontSize:18,fontWeight:700,color:T.text}}>✨ {knownSet.size}/{ALL_CARDS.length}</div><div style={{fontSize:13,color:T.sub,marginTop:3}}>⏱️ {Math.floor((stats.totalMinutes||0)/60)}h {Math.round((stats.totalMinutes||0)%60)}m</div><div style={{fontSize:11,color:T.muted,marginTop:4}}>{showCatBreakdown?"▲ Hide categories":"▼ Tap for category breakdown"}</div></div></div>
          {/* ——— Category breakdown (collapsible) ——— */}
          {showCatBreakdown&&<div style={{padding:"14px",borderRadius:20,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:12,boxShadow:T.catCardShadow,animation:"hintIn .3s ease-out"}}><div style={{fontSize:15,fontWeight:700,color:T.text,marginBottom:10}}>📂 {u.cats}</div>{Object.entries(CC).map(([cat,col])=>{const cc=ALL_CARDS.filter(c=>c.cat===cat);const m=cc.filter(c=>getLevel(cardLevels,c.id).level>=5).length;const cp=cc.length?Math.round((m/cc.length)*100):0;return(<div key={cat} style={{marginBottom:7}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{fontSize:13,fontWeight:600,color:col}}>{catName(cat)}</span><span style={{fontSize:11,color:T.muted}}>{m}/{cc.length}</span></div><div style={{height:5,borderRadius:3,background:T.dotBg,overflow:"hidden"}}><div style={{height:"100%",borderRadius:3,width:`${cp}%`,background:col}}/></div></div>);})}</div>}
          {/* ——— STREAK CALENDAR ——— */}
          {(()=>{
            const log=stats.dailyLog||{};
            const now=new Date();
            const yr=now.getFullYear(),mo=now.getMonth();
            const daysInMonth=new Date(yr,mo+1,0).getDate();
            const firstDow=(new Date(yr,mo,1).getDay()+6)%7; // Mon=0
            const todayDate=now.getDate();
            const moNames=lang==="de"?["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"]:["January","February","March","April","May","June","July","August","September","October","November","December"];
            const dayLabels=lang==="de"?["Mo","Di","Mi","Do","Fr","Sa","So"]:["M","T","W","T","F","S","S"];
            // Build completion map for this month
            const isComplete=(day)=>{
              const k=`${yr}-${String(mo+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
              return(log[k]||0)>=dailyTarget;
            };
            const getCount=(day)=>{
              const k=`${yr}-${String(mo+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
              return log[k]||0;
            };
            // Check consecutive completion for "chain" lines
            const isCompleteDay=(day)=>day>=1&&day<=daysInMonth&&isComplete(day);
            return(
            <div style={{padding:"16px",borderRadius:20,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:12,boxShadow:T.catCardShadow}}>
              {/* Header */}
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
                <div style={{fontSize:15,fontWeight:700,color:T.text}}>🔥 {lang==="de"?"Streak-Kalender":"Streak Calendar"}</div>
                {streak>0&&<div style={{padding:"4px 12px",borderRadius:10,background:"#D8905014",border:"1px solid #D8905030"}}><span style={{fontSize:13,fontWeight:800,color:"#D89050"}}>{streak} {lang==="de"?"Tage":"day"}{streak!==1&&lang!=="de"?"s":""} 🔥</span></div>}
              </div>
              {/* Month label */}
              <div style={{fontSize:13,fontWeight:600,color:T.muted,marginBottom:8,textAlign:"center"}}>{moNames[mo]} {yr}</div>
              {/* Day headers */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2,marginBottom:4}}>
                {dayLabels.map((d,i)=><div key={i} style={{textAlign:"center",fontSize:10,fontWeight:600,color:T.muted,padding:"2px 0"}}>{d}</div>)}
              </div>
              {/* Calendar grid */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:3}}>
                {/* Empty cells for offset */}
                {Array.from({length:firstDow},(_,i)=><div key={`e${i}`}/>)}
                {/* Day cells */}
                {Array.from({length:daysInMonth},(_,i)=>{
                  const day=i+1;
                  const isFuture=day>todayDate;
                  const isToday=day===todayDate;
                  const done=isComplete(day);
                  const cnt=getCount(day);
                  const missed=!isFuture&&!isToday&&!done&&day<todayDate;
                  // Chain: thick connector if this day and previous day are both complete
                  const prevDone=isCompleteDay(day-1);
                  const dayDow=(firstDow+i)%7; // 0=Mon
                  const chainLeft=done&&prevDone&&dayDow!==0; // no chain on Monday (row start)
                  return(
                    <div key={day} style={{position:"relative",display:"flex",alignItems:"center",justifyContent:"center"}}>
                      {/* Chain connector line */}
                      {chainLeft&&<div style={{position:"absolute",left:-3,top:"50%",transform:"translateY(-50%)",width:6,height:4,borderRadius:2,background:T.accent,zIndex:1}}/>}
                      <div style={{
                        width:34,height:34,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:isToday||done?700:500,
                        background:done?T.accent:isToday?`${T.accent}12`:"transparent",
                        color:done?"#FFF":isFuture?T.faint:isToday?T.accent:missed?T.muted:T.sub,
                        border:missed?`1.5px dashed ${T.faint}`:isToday&&!done?`2px solid ${T.accent}`:`1.5px solid transparent`,
                        animation:isToday&&!done?"todayPulse 2s ease-in-out infinite":"none",
                        opacity:isFuture?.35:1,position:"relative",
                      }}>
                        {done&&!isToday?<span style={{fontSize:12}}>🔥</span>:day}
                        {isToday&&done&&<span style={{fontSize:12}}>🔥</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
              {/* Legend */}
              <div style={{display:"flex",gap:12,justifyContent:"center",marginTop:10,flexWrap:"wrap"}}>
                <div style={{display:"flex",alignItems:"center",gap:4}}><div style={{width:10,height:10,borderRadius:"50%",background:T.accent}}/><span style={{fontSize:10,color:T.muted}}>{lang==="de"?"Geschafft":"Completed"}</span></div>
                <div style={{display:"flex",alignItems:"center",gap:4}}><div style={{width:10,height:10,borderRadius:"50%",border:`1.5px dashed ${T.faint}`}}/><span style={{fontSize:10,color:T.muted}}>{lang==="de"?"Verpasst":"Missed"}</span></div>
                <div style={{display:"flex",alignItems:"center",gap:4}}><div style={{width:10,height:10,borderRadius:"50%",border:`2px solid ${T.accent}`}}/><span style={{fontSize:10,color:T.muted}}>{lang==="de"?"Heute":"Today"}</span></div>
              </div>
            </div>
            );
          })()}
          {/* ——— This week bar chart ——— */}
          <div style={{padding:"14px",borderRadius:20,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:12,boxShadow:T.catCardShadow}}><div style={{fontSize:15,fontWeight:700,color:T.text,marginBottom:10}}>📅 {u.week}</div><div style={{display:"flex",gap:5,alignItems:"flex-end",height:80}}>{Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-6+i);const k=d.toISOString().slice(0,10);const c=(stats.dailyLog||{})[k]||0;const isT=k===today;const max=Math.max(...Object.values(stats.dailyLog||{1:1}),dailyTarget,1);return(<div key={k} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3}}><div style={{fontSize:10,fontWeight:700,color:isT?T.accent:T.muted}}>{c}</div><div style={{width:"100%",borderRadius:5,background:isT?T.accent:T.barFill,opacity:isT?1:.3,height:`${Math.max((c/max)*55,3)}px`}}/><div style={{fontSize:9,color:isT?T.accent:T.muted,fontWeight:isT?700:500}}>{d.toLocaleDateString(lang==="de"?"de":"en",{weekday:"short"})}</div></div>);})}</div></div>
          <div style={{padding:"14px",borderRadius:20,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:12,boxShadow:T.catCardShadow}}><div style={{fontSize:15,fontWeight:700,color:T.text,marginBottom:10}}>🏆 {u.levels}</div>{[1,2,3,4,5].map(lv=>{const ct=ALL_CARDS.filter(c=>{const l=getLevel(cardLevels,c.id).level;return lv===1?(l===1||!cardLevels[c.id]):l===lv;}).length;return(<div key={lv} style={{display:"flex",alignItems:"center",gap:8,marginBottom:5}}><div style={{width:70,fontSize:12,fontWeight:700,color:LVL_C[lv-1]}}>{lvlNames[lv-1]}</div><div style={{flex:1,height:6,borderRadius:3,background:T.dotBg,overflow:"hidden"}}><div style={{height:"100%",borderRadius:3,width:`${(ct/ALL_CARDS.length)*100}%`,background:LVL_C[lv-1]}}/></div><div style={{width:24,fontSize:12,fontWeight:600,color:T.muted,textAlign:"right"}}>{ct}</div></div>);})}</div>
        </div>}

        {tab==="settings"&&<div>
          <h2 style={{fontSize:24,fontWeight:800,color:T.text,margin:"0 0 16px"}}>⚙️ {u.settings}</h2>
          <p style={{fontSize:14,color:T.sub,margin:"0 0 16px"}}>{displayName} · {user.email}</p>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px",borderRadius:16,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:8,boxShadow:T.catCardShadow}}><span style={{fontSize:15,fontWeight:700,color:T.text}}>🌐 {u.lang}</span><div style={{display:"flex",gap:5}}>{[{k:"en",l:"English"},{k:"de",l:"Deutsch"}].map(o=>(<button key={o.k} onClick={()=>setLang(o.k)} style={{padding:"7px 12px",borderRadius:12,border:`1.5px solid ${lang===o.k?T.accent+"44":T.pillBd}`,background:lang===o.k?`${T.accent}14`:T.btnBg,color:lang===o.k?T.accent:T.text,fontSize:13,fontFamily:"inherit",fontWeight:lang===o.k?700:500,cursor:"pointer"}}>{o.l}</button>))}</div></div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px",borderRadius:16,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:8,boxShadow:T.catCardShadow}}><span style={{fontSize:15,fontWeight:700,color:T.text}}>🌓 {u.theme}</span><button onClick={()=>setDark(d=>!d)} style={{padding:"7px 14px",borderRadius:12,border:`1.5px solid ${T.pillBd}`,background:T.btnBg,color:T.text,fontSize:13,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>{dark?"☀️ Light":"🌙 Dark"}</button></div>
          {supported&&<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px",borderRadius:16,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:8,boxShadow:T.catCardShadow}}><span style={{fontSize:15,fontWeight:700,color:T.text}}>🔊 {u.autoPlay}</span><button onClick={()=>setAutoSpeak(a=>!a)} style={{padding:"7px 14px",borderRadius:12,border:`1.5px solid ${autoSpeak?T.accent+"44":T.pillBd}`,background:autoSpeak?`${T.accent}14`:T.btnBg,color:autoSpeak?T.accent:T.text,fontSize:13,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>{autoSpeak?"ON":"OFF"}</button></div>}
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px",borderRadius:16,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:8,boxShadow:T.catCardShadow}}><div><div style={{fontSize:15,fontWeight:700,color:T.text}}>🎯 {u.target}</div><div style={{fontSize:12,color:T.muted}}>{dailyTarget}{u.perDay}</div></div><div style={{display:"flex",gap:5}}>{[15,25,40,60].map(n=>(<button key={n} onClick={()=>setStats(p=>({...p,dailyTarget:n}))} style={{padding:"6px 10px",borderRadius:10,border:`1.5px solid ${dailyTarget===n?T.accent+"44":T.pillBd}`,background:dailyTarget===n?`${T.accent}14`:"transparent",color:dailyTarget===n?T.accent:T.muted,fontSize:12,fontFamily:"inherit",fontWeight:700,cursor:"pointer"}}>{n}</button>))}</div></div>
          <button onClick={()=>setShowTutorial(true)} style={{width:"100%",padding:"14px",borderRadius:16,border:`1px solid ${T.pillBd}`,background:T.pillBg,color:T.text,fontSize:14,fontFamily:"inherit",fontWeight:600,cursor:"pointer",marginBottom:8,boxShadow:T.catCardShadow}}>📖 {u.replay}</button>
          {/* ——— PWA Install Button ——— */}
          {(()=>{
            // Hide if already installed as PWA
            if(pwa.isInstalled)return(<div style={{padding:"14px",borderRadius:16,background:`${T.accent}08`,border:`1px solid ${T.accent}20`,marginBottom:8,display:"flex",alignItems:"center",gap:10}}><span style={{fontSize:20}}>✅</span><div><div style={{fontSize:14,fontWeight:700,color:T.accent}}>{u.installed}</div><div style={{fontSize:11,color:T.muted}}>{lang==="de"?"Als App geöffnet":"Running as installed app"}</div></div></div>);
            // Show install button for iOS (always) or Android/Desktop (when prompt available)
            const showBtn=pwa.isIOS||pwa.canInstall;
            if(!showBtn)return null;
            return(
              <div style={{marginBottom:8}}>
                <button onClick={handleInstallClick} style={{width:"100%",padding:"14px 16px",borderRadius:16,border:`2px solid ${T.accent}40`,background:`linear-gradient(135deg,${T.accent}0A,${T.accent}14)`,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:12,boxShadow:`0 2px 12px ${T.accent}15`}}>
                  <span style={{fontSize:26}}>📲</span>
                  <div style={{textAlign:"left",flex:1}}>
                    <div style={{fontSize:15,fontWeight:700,color:T.accent}}>{u.installApp}</div>
                    <div style={{fontSize:12,color:T.muted,marginTop:2}}>{u.installDesc}</div>
                  </div>
                  <span style={{fontSize:18,color:T.accent}}>→</span>
                </button>
                {installFeedback&&<div style={{marginTop:6,padding:"8px 12px",borderRadius:10,background:`${T.accent}10`,fontSize:12,fontWeight:600,color:T.accent,textAlign:"center"}}>{installFeedback}</div>}
              </div>
            );
          })()}
          <div style={{padding:"14px",borderRadius:16,background:T.pillBg,border:`1px solid ${T.pillBd}`,marginBottom:8,boxShadow:T.catCardShadow}}>
            <div style={{fontSize:15,fontWeight:700,color:T.text,marginBottom:6}}>⏩ {lang==="de"?"Zeitsimulation (Debug)":"Time Simulation (Debug)"}</div>
            <div style={{fontSize:12,color:T.muted,marginBottom:8}}>{timeOffset>0?`+${Math.round(timeOffset/36e5)}h offset (${new Date(Date.now()+timeOffset).toLocaleString()})`:"No offset — real time"}</div>
            <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>{[{l:"Reset",v:0},{l:"+1h",v:36e5},{l:"+12h",v:12*36e5},{l:"+48h",v:48*36e5},{l:"+4d",v:96*36e5},{l:"+7d",v:7*864e5},{l:"+30d",v:30*864e5}].map(o=>(<button key={o.l} onClick={()=>setTimeOffset(o.v===0?0:timeOffset+o.v)} style={{padding:"5px 10px",borderRadius:10,border:`1.5px solid ${o.v===0?(timeOffset===0?T.accent+"44":T.pillBd):(T.pillBd)}`,background:o.v===0&&timeOffset===0?`${T.accent}14`:"transparent",color:o.v===0?T.accent:T.sub,fontSize:12,fontFamily:"inherit",fontWeight:600,cursor:"pointer"}}>{o.l}</button>))}</div>
          </div>
          <button onClick={handleLogout} style={{width:"100%",padding:"14px",borderRadius:16,border:`1px solid ${T.pillBd}`,background:T.pillBg,color:T.text,fontSize:15,fontFamily:"inherit",fontWeight:700,cursor:"pointer",marginBottom:16,boxShadow:T.catCardShadow}}>🚪 {u.logout}</button>
          <div style={{padding:"14px",borderRadius:16,border:"1.5px solid #D0606030",background:"#D0606008"}}><DeleteBtn T={T} u={u}/></div>
        </div>}
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,zIndex:50,background:T.tabBg,borderTop:`1px solid ${T.tabBd}`,display:"flex",justifyContent:"center",backdropFilter:"blur(16px)"}}><div style={{display:"flex",maxWidth:560,width:"100%"}}>{[{k:"practice",i:"📚",l:u.practice},{k:"progress",i:"📊",l:u.progress},{k:"settings",i:"⚙️",l:u.settings}].map(t=>(<button key={t.k} onClick={()=>{setTab(t.k);if(t.k==="practice"&&!inCardView){setActiveCategory(null);setPracticeMode(null);}stop();}} style={{flex:1,padding:"10px 0 8px",border:"none",background:"transparent",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:2,fontFamily:"inherit",color:tab===t.k?T.accent:T.muted}}><span style={{fontSize:22}}>{t.i}</span><span style={{fontSize:11,fontWeight:tab===t.k?700:500}}>{t.l}</span>{tab===t.k&&<div style={{width:20,height:3,borderRadius:2,background:T.accent}}/>}</button>))}</div></div>
    </div>
  );
}

function DeleteBtn({T,u}){const[cd,setCd]=useState(false);const[dp,setDp]=useState("");const[de,setDe]=useState("");const[dl,setDl]=useState(false);const hd=async()=>{if(!cd){setCd(true);return;}if(!dp){setDe(u.pw);return;}setDl(true);try{const c=EmailAuthProvider.credential(auth.currentUser.email,dp);await reauthenticateWithCredential(auth.currentUser,c);await deleteDoc(doc(db,"users",auth.currentUser.uid));await deleteUser(auth.currentUser);}catch(e){setDe("Wrong password.");setDl(false);}};return(<><div style={{fontSize:14,fontWeight:700,color:"#C03040",marginBottom:4}}>⚠️ {u.deleteAcc}</div><div style={{fontSize:11,color:T.muted,marginBottom:8}}>{u.deleteWarn}</div>{cd&&<><PasswordInput value={dp} onChange={e=>setDp(e.target.value)} placeholder={u.pw} T={T} onKeyDown={e=>e.key==="Enter"&&hd()}/>{de&&<div style={{marginTop:6,fontSize:11,color:"#C03040"}}>{de}</div>}</>}<button onClick={hd} disabled={dl} style={{width:"100%",padding:"10px",borderRadius:12,border:"none",background:cd?"#C03040":"transparent",color:cd?"#FFF":"#C03040",fontSize:13,fontFamily:"'Outfit',sans-serif",fontWeight:700,cursor:dl?"wait":"pointer",marginTop:8,opacity:dl?.6:1}}>{dl?"...":cd?u.confirm:u.deleteAcc}</button>{cd&&<button onClick={()=>{setCd(false);setDe("");setDp("");}} style={{width:"100%",padding:"6px",border:"none",background:"transparent",color:T.muted,fontSize:12,fontFamily:"inherit",cursor:"pointer",marginTop:4}}>{u.cancel}</button>}</>);}
